import Homepage from "./components/Homepage";

export default function Home() {
    return <div className="max-auto-screen">
        <Homepage/>
    </div>
}