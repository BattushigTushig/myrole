export default function Sgchall() {
    return <div className="bg-emerald-50 m-auto-screen h-[100vh]">
    <div className="flex flex-col justify-center items-center gap-20 pt-30">
        <div className="flex flex-col justify-center items-center  rounded-xl px-30 py-20 w-250 h-140 bg-gray-200">
            <div className=" flex flex-col gap-4 justify-items-start pt-6 text-xl">
            <h1>{"Үр дүн:"+result}</h1>
            </div>
        </div>
    </div>
</div>
}