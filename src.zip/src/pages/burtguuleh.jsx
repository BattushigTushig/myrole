import Burtguuleh from "./components/Burtguuleh";

export default function Home(){
    return <div>
        <Burtguuleh/>
    </div>
}