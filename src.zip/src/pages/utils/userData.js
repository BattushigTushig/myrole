const userMedeelel = [
    {
        class: "10",
        buleg: "b",
        lastName: "Batbold",
        firstName: "Misheel",
        score: 8,
        category:"Tugshuur",
        date: "3-р caрын 30"
    },
    {
        class: "12",
        buleg: "a",
        lastName: "Chuluun",
        firstName: "Bolor",
        score: 4,
        category:"Өөртөө итгэх итгэл",
        date: "2-р caрын 10"
    },
    {
        class: "07",
        buleg: "d",
        lastName: "Monh",
        firstName: "Hurlee",
        score: 1,
        category:"Setgel gutral",
        date: "1-р caрын 30"
    },
    {
        class: "11",
        buleg: "b",
        lastName: "Bat",
        firstName: "Nomin",
        score: 2,
        category:"Stress",
        date: "12-р caрын 4"
    },
]
export default userMedeelel;