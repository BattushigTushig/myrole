export default function Result1(){
  return <div>
    <div>
      
    </div>
  </div>
}