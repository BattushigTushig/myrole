export default function Diagnose({props}){
    return <div>
        
    </div>
}