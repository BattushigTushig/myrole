import StudentResult from "./components/StudentResult";

export default function Home(){
   
    return <div>

        <StudentResult/>
    </div>
}