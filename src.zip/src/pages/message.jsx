import Message from "./components/Message";

export default function Home() {
    return <div>
        <Message/>
    </div>
}